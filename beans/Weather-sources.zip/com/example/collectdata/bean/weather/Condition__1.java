
package com.example.collectdata.bean.weather;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class Condition__1 {


}
